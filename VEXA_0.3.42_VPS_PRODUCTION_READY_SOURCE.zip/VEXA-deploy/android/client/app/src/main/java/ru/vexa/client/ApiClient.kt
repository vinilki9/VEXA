
package ru.vexa.client

import android.content.Context
import java.util.UUID
import java.util.concurrent.TimeUnit

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.RequestBody.Companion.toRequestBody

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Ошибка HTTP с доступным клиенту кодом ответа для обработки 401/403/409. */
class ApiHttpException(val statusCode: Int, detail: String) :
    Exception("Ошибка сервера: $statusCode $detail")

object ApiClient {

    private val BASE_URL = BuildConfig.VEXA_API_BASE_URL
    private val DEFAULT_CITY_CODE = BuildConfig.VEXA_CITY_CODE

    private val JSON_MEDIA_TYPE =
        "application/json; charset=utf-8".toMediaType()

    @Volatile
    private var accessToken: String? = null

    @Volatile
    private var passengerPhone: String? = null

    @Volatile
    private var applicationContext: Context? = null

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Инициализировать клиент и восстановить защищённую сессию.
     *
     * Вызывается один раз из VexaApplication.onCreate().
     */
    @Synchronized
    fun initializeSession(context: Context) {
        val appContext = context.applicationContext
        applicationContext = appContext

        val session = PassengerSessionStore.loadSession(appContext)

        accessToken = session?.accessToken
        passengerPhone = session?.passengerPhone
    }

    /**
     * Сохранить подтверждённую сессию пассажира.
     *
     * Токен и телефон сохраняются одной зашифрованной записью.
     * Сначала выполняется сохранение на диск, затем обновляется память.
     */
    @Synchronized
    fun setPassengerSession(
        token: String,
        phone: String
    ) {
        val normalizedToken = token.trim()
        val normalizedPhone = phone.trim()

        require(normalizedToken.isNotEmpty()) {
            "Не получен токен авторизации"
        }

        require(normalizedPhone.isNotEmpty()) {
            "Не указан номер телефона пассажира"
        }

        val context = applicationContext
            ?: throw IllegalStateException(
                "Защищённое хранилище VEXA не инициализировано"
            )

        PassengerSessionStore.saveSession(
            context = context,
            accessToken = normalizedToken,
            passengerPhone = normalizedPhone
        )

        accessToken = normalizedToken
        passengerPhone = normalizedPhone
    }

    /**
     * Получить текущий JWT-токен.
     */
    fun getAccessToken(): String? {
        return accessToken
    }

    /**
     * Получить номер телефона авторизованного пассажира.
     */
    fun getPassengerPhone(): String? {
        return passengerPhone
    }

    /**
     * Завершить текущую авторизацию и удалить защищённую сессию.
     */
    @Synchronized
    fun clearAccessToken() {
        accessToken = null
        passengerPhone = null

        applicationContext?.let { context ->
            PassengerSessionStore.clearSession(context)
        }
    }

    /**
     * Экранирование строки для JSON.
     */
    private fun jsonString(value: String): String {
        val escaped = value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\b", "\\b")
            .replace("\u000C", "\\f")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")

        return "\"$escaped\""
    }

    /**
     * Выполнить HTTP-запрос и вернуть тело ответа.
     */
    private suspend fun executeRequest(
        request: Request
    ): String {
        return withContext(Dispatchers.IO) {
            client.newCall(request).execute().use { response ->
                val result = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    throw ApiHttpException(response.code, result)
                }

                result
            }
        }
    }

    /**
     * Предварительно рассчитать стоимость поездки.
     *
     * POST /api/v1/orders/price-preview
     *
     * Заказ не создаётся.
     * Требуется подтверждённая авторизация пассажира.
     */
    suspend fun previewOrderPrice(
        json: String
    ): String {
        val token = accessToken
            ?: throw IllegalStateException(
                "Для расчёта стоимости необходимо войти в профиль"
            )

        val request = Request.Builder()
            .url("$BASE_URL/api/v1/orders/price-preview")
            .header("Authorization", "Bearer $token")
            .post(json.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        return executeRequest(request)
    }

    /**
     * Получить список активных тарифов города.
     *
     * GET /api/v1/tariffs/{city_code}
     */
    suspend fun getTariffs(
        cityCode: String = DEFAULT_CITY_CODE
    ): String {
        val normalizedCityCode = cityCode.trim()

        require(normalizedCityCode.isNotEmpty()) {
            "Не указан код города"
        }

        val request = Request.Builder()
            .url("$BASE_URL/api/v1/tariffs/$normalizedCityCode")
            .get()
            .build()

        return executeRequest(request)
    }

    /**
     * Получить список активных городов.
     *
     * GET /api/v1/cities
     */
    suspend fun getCities(): String {
        val request = Request.Builder()
            .url("$BASE_URL/api/v1/cities")
            .get()
            .build()

        return executeRequest(request)
    }

    /**
     * Запросить SMS-авторизацию пассажира.
     *
     * POST /api/v1/auth/passenger/request
     */
    suspend fun getLegalDocuments(role: String): String =
        executeRequest(Request.Builder().url("$BASE_URL/api/v1/legal/roles/$role").get().build())

    suspend fun getLegalDocument(role: String, id: String): String =
        executeRequest(Request.Builder().url("$BASE_URL/api/v1/legal/roles/$role/$id").get().build())

    suspend fun requestPassengerAuth(
        phone: String,
        legalAcceptancesJson: String
    ): String {
        val json = """
            {
                "phone": ${jsonString(phone)},
                "legal_acceptances": $legalAcceptancesJson
            }
        """.trimIndent()

        val request = Request.Builder()
            .url("$BASE_URL/api/v1/auth/passenger/request")
            .post(json.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        return executeRequest(request)
    }

    /**
     * Проверить состояние SMS-авторизации.
     *
     * GET /api/v1/auth/passenger/sessions/{session_id}
     */
    suspend fun getPassengerAuthStatus(
        sessionId: String
    ): String {
        val request = Request.Builder()
            .url("$BASE_URL/api/v1/auth/passenger/sessions/$sessionId")
            .get()
            .build()

        return executeRequest(request)
    }

    /**
     * Передать SMS-код для проверки.
     *
     * POST /api/v1/auth/passenger/verify
     *
     * После проверки необходимо отдельно запросить статус сессии.
     */
    suspend fun verifyPassengerAuth(
        sessionId: String,
        code: String
    ): String {
        val json = """
            {
                "session_id": ${jsonString(sessionId)},
                "code": ${jsonString(code)}
            }
        """.trimIndent()

        val request = Request.Builder()
            .url("$BASE_URL/api/v1/auth/passenger/verify")
            .post(json.toRequestBody(JSON_MEDIA_TYPE))
            .build()

        return executeRequest(request)
    }

    /**
     * Отправить заказ на сервер VEXA.
     *
     * POST /api/v1/orders
     *
     * Требуется подтверждённая авторизация пассажира.
     * Для защиты от повторной отправки используется Idempotency-Key.
     */
    suspend fun sendOrder(
        json: String,
        idempotencyKey: String = UUID.randomUUID().toString()
    ): String {
        val token = accessToken
            ?: throw IllegalStateException(
                "Для оформления заказа необходимо войти в профиль"
            )

        val body = json.toRequestBody(JSON_MEDIA_TYPE)

        val request = Request.Builder()
            .url("$BASE_URL/api/v1/orders")
            .header("Authorization", "Bearer $token")
            .header("Idempotency-Key", idempotencyKey)
            .post(body)
            .build()

        return executeRequest(request)
    }

    /**
     * Получить один заказ по UUID или публичному номеру.
     * Сервер возвращает только заказы текущего пассажира.
     */
    suspend fun getPassengerOrder(orderIdentifier: String): String {
        val token = accessToken
            ?: throw IllegalStateException(
                "Для просмотра заказа необходимо войти в профиль"
            )

        require(orderIdentifier.isNotBlank() && orderIdentifier.length <= 80) {
            "Некорректный идентификатор заказа"
        }

        val url = BASE_URL.toHttpUrl()
            .newBuilder()
            .addPathSegments("api/v1/passenger/orders")
            .addPathSegment(orderIdentifier)
            .build()

        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .get()
            .build()

        return executeRequest(request)
    }

    /** Отменить свой ещё не назначенный заказ (POST, идемпотентно). */
    suspend fun cancelPassengerOrder(orderIdentifier: String): String {
        val token = accessToken
            ?: throw IllegalStateException("Для отмены заказа войдите в профиль")
        require(orderIdentifier.isNotBlank() && orderIdentifier.length <= 80) {
            "Некорректный идентификатор заказа"
        }
        val url = BASE_URL.toHttpUrl()
            .newBuilder()
            .addPathSegments("api/v1/passenger/orders")
            .addPathSegment(orderIdentifier)
            .addPathSegment("cancel")
            .build()
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .post("".toRequestBody(JSON_MEDIA_TYPE))
            .build()
        return executeRequest(request)
    }

    /**
     * Получить историю заказов пассажира.
     *
     * GET /api/v1/passenger/orders
     */
    suspend fun getPassengerOrders(): String {
        val token = accessToken
            ?: throw IllegalStateException(
                "Для просмотра заказов необходимо войти в профиль"
            )

        val request = Request.Builder()
            .url("$BASE_URL/api/v1/passenger/orders")
            .header("Authorization", "Bearer $token")
            .get()
            .build()

        return executeRequest(request)
    }
}
