
from logging.config import fileConfig

from alembic import context
from sqlalchemy import create_engine, pool, text

from app.config import settings
from app.database import Base
from app import models  # noqa: F401 — register models in Base.metadata
from app import driver_transfer_models  # noqa: F401 — register transfer models in Base.metadata
from app import auth_models  # noqa: F401 — register authentication models in Base.metadata
from app import driver_order_offer_models  # noqa: F401 — register driver order offer models in Base.metadata
from app import organization_models  # noqa: F401 — register organization models in Base.metadata
from app import application_models  # noqa: F401 — register application models in Base.metadata
from app import organization_access_models  # noqa: F401 — register organization access models in Base.metadata


config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    """Run migrations without creating a database connection."""
    context.configure(
        url=settings.database_url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations using the configured database connection."""
    connectable = create_engine(
        settings.database_url,
        poolclass=pool.NullPool,
        pool_pre_ping=True,
    )

    try:
        with connectable.begin() as connection:
            # Historic revision identifiers exceed Alembic's default VARCHAR(32).
            # Preserve existing version rows; provision/widen before Alembic runs.
            if connection.dialect.name == "postgresql":
                connection.execute(text("CREATE TABLE IF NOT EXISTS alembic_version (version_num VARCHAR(128) NOT NULL PRIMARY KEY)"))
                connection.execute(text("ALTER TABLE alembic_version ALTER COLUMN version_num TYPE VARCHAR(128)"))
            context.configure(
                connection=connection,
                target_metadata=target_metadata,
                compare_type=True,
            )

            with context.begin_transaction():
                context.run_migrations()
    finally:
        connectable.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
