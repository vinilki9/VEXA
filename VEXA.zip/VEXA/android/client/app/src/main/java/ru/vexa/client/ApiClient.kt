package ru.vexa.client

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ApiClient {

    private const val BASE_URL = "https://109.120.184.20"

    val client = OkHttpClient()

    suspend fun sendOrder(json: String): String {
        return withContext(Dispatchers.IO) {

            val body = json.toRequestBody(
                "application/json; charset=utf-8".toMediaType()
            )

            val request = Request.Builder()
                .url("$BASE_URL/api/orders")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val result = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    throw Exception(
                        "Ошибка сервера: ${response.code} $result"
                    )
                }

                result
            }
        }
    }
}