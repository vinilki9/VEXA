package ru.vexa.client

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.Executors

data class AddressResult(
    val name: String,
    val latitude: Double,
    val longitude: Double
)

object AddressSearch {

    private val client = OkHttpClient()
    private val executor = Executors.newSingleThreadExecutor()

    fun search(
        query: String,
        onResult: (List<AddressResult>) -> Unit,
        onError: (String) -> Unit
    ) {
        if (query.isBlank()) {
            onResult(emptyList())
            return
        }

        executor.execute {
            try {
                val encodedQuery = URLEncoder.encode(query, "UTF-8")

                val url = "https://photon.komoot.io/api/" +
                        "?q=$encodedQuery" +
                        "&limit=7"


                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "VEXA-Client/1.0")
                    .build()

                client.newCall(request).execute().use { response ->

                    if (!response.isSuccessful) {
                        val errorBody = response.body?.string().orEmpty()

                        throw Exception(
                            "Ошибка сервера: ${response.code}. $errorBody"
                        )
                    }

                    val body = response.body?.string()
                        ?: throw Exception("Пустой ответ сервера")

                    val json = JSONObject(body)
                    val features = json.getJSONArray("features")

                    val results = mutableListOf<AddressResult>()

                    for (i in 0 until features.length()) {

                        val feature = features.getJSONObject(i)
                        val properties = feature.getJSONObject("properties")

                        val coordinates = feature
                            .getJSONObject("geometry")
                            .getJSONArray("coordinates")

                        val street = properties.optString("street")
                        val house = properties.optString("housenumber")
                        val city = properties.optString("city")
                        val district = properties.optString("district")
                        val objectName = properties.optString("name")

                        val name = buildString {

                            val address = when {
                                street.isNotBlank() && house.isNotBlank() ->
                                    "$street, $house"

                                street.isNotBlank() ->
                                    street

                                objectName.isNotBlank() ->
                                    objectName

                                else -> ""
                            }

                            append(address)

                            if (district.isNotBlank()) {
                                if (isNotEmpty()) append(", ")
                                append(district)
                            }

                            if (city.isNotBlank()) {
                                if (isNotEmpty()) append(", ")
                                append(city)
                            }
                        }

                        if (name.isNotBlank()) {
                            results.add(
                                AddressResult(
                                    name = name,
                                    longitude = coordinates.getDouble(0),
                                    latitude = coordinates.getDouble(1)
                                )
                            )
                        }
                    }

                    android.os.Handler(
                        android.os.Looper.getMainLooper()
                    ).post {
                        onResult(results)
                    }
                }

            } catch (e: Exception) {

                android.os.Handler(
                    android.os.Looper.getMainLooper()
                ).post {
                    onError(
                        e.message ?: "Неизвестная ошибка поиска"
                    )
                }
            }
        }
    }
}